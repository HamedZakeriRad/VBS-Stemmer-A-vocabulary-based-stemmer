<?php
class config {
var $hostname = "localhost";
var $username = "root";
var $password = "";
var $dbName = "vocabulary";  
}

?>
    